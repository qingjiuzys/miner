function generateRandomString(length) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}


function simulateKeyboardInput(target, value) {
  const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
  const inputEvent = new Event('input', { bubbles: true });
  const keydownEvent = new Event('keydown', { bubbles: true });
  const keyupEvent = new Event('keyup', { bubbles: true });

  for (let i = 0; i < value.length; i++) {
    const char = value[i];
    nativeInputValueSetter.call(target, target.value + char);
    target.dispatchEvent(keydownEvent);
    target.dispatchEvent(inputEvent);
    target.dispatchEvent(keyupEvent);
  }
}

function simulateClick(element) {
  const clickEvent = new MouseEvent('click', {
    'view': window,
    'bubbles': true,
    'cancelable': false
  });
  element.dispatchEvent(clickEvent);
}


function fillAndSubmitForm() {
  var times = 0;
  const emailInput = document.querySelector('input[type="email"]');
  const passwordInput = document.querySelector('input[type="password"]');
  const submitButton = document.querySelector('button.el-button.submit');

  if (emailInput && passwordInput && submitButton) {
    const emailLocalPart = generateRandomString(10);
    const emailDomain = "gmail.com";
    const email = `${emailLocalPart}@${emailDomain}`;
    const password = generateRandomString(12);

    simulateKeyboardInput(emailInput, email);
    simulateKeyboardInput(passwordInput, password);
    submitButton.click();

    // 检查是否跳转到了新页面或页面状态变化
    const checkForNavigation = setInterval(() => {
      const inProgress = document.querySelector('uni-view.inProgress');
      if (inProgress) {
        clearInterval(checkForNavigation);
        times = 0;
        setTimeout(() => {
          simulateClick(inProgress);
          // 在点击后延迟一段时间再刷新页面
          setTimeout(() => {
            location.href = 'https://app.chatai.style/#/pages/sign-up?invite=EBQJEVUD';
          }, 3000); // 延迟2000毫秒（2秒）后刷新页面
        }, 2000); // 延迟2000毫秒（5秒）后点击
      }else{
        times = times + 1;
        if(times > 5){
            location.href = 'https://app.chatai.style/#/pages/sign-up?invite=EBQJEVUD';
        }
      }
    }, 1000); // 每秒检查一次
  }
}

window.addEventListener('load', () => {
  fillAndSubmitForm();
});
