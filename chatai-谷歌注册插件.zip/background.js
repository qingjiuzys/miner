// background.js
chrome.runtime.onInstalled.addListener(() => {
  console.log('Auto Form Filler installed.');
});
